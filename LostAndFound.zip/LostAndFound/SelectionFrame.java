package LostAndFound;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class SelectionFrame extends JFrame {
    public SelectionFrame() {
        setTitle("Select User Type");
        setSize(700, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        getContentPane().setLayout(null);

        getContentPane().setBackground(new Color(153, 0, 0));


        JPanel topPanel = new JPanel();
        topPanel.setBackground(Color.white);
        topPanel.setBounds(0, 0, 700, 100);
        topPanel.setLayout(null);

        JLabel titleLabel = new JLabel("DHA SUFFA LOST & FOUND SYSTEM", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 30));
        titleLabel.setForeground(new Color(153,0,0));
        titleLabel.setBounds(50, 25, 600, 50);
        topPanel.add(titleLabel);

        add(topPanel);


        JLabel adminLabel = new JLabel("Admin", SwingConstants.CENTER);
        adminLabel.setFont(new Font("Arial", Font.BOLD, 24));
        adminLabel.setForeground(Color.white);
        adminLabel.setBounds(100, 200, 200, 30);
        add(adminLabel);


        JButton adminButton = new JButton();
        adminButton.setPreferredSize(new Dimension(200, 190));
        adminButton.setIcon(new ImageIcon(getClass().getResource("images-removebg-preview copy.jpg")));
        adminButton.setBorder(BorderFactory.createSoftBevelBorder(0));
        adminButton.setBounds(100, 240, 200, 190);
        adminButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new MainFrame(true).setVisible(true);
                dispose();
            }
        });
        add(adminButton);


        JLabel userLabel = new JLabel("User", SwingConstants.CENTER);
        userLabel.setFont(new Font("Arial", Font.BOLD, 24));
        userLabel.setForeground(Color.white);
        userLabel.setBounds(350, 200, 200, 30);
        add(userLabel);


        JButton userButton = new JButton();
        userButton.setIcon(new ImageIcon(getClass().getResource("m.jpg")));
        userButton.setPreferredSize(new Dimension(200, 170));
        userButton.setBorder(BorderFactory.createSoftBevelBorder(0));
        userButton.setBounds(350, 240, 200, 190);
        userButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new MainFrame(false).setVisible(true);
                dispose();
            }
        });
        add(userButton);

        setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new SelectionFrame();
            }
        });
    }
}
