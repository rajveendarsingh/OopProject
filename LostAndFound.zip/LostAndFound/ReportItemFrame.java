package LostAndFound;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ReportItemFrame extends JFrame {
    private boolean isLost;
    private ItemDAO itemDAO;

    public ReportItemFrame(boolean isLost) {
        this.isLost = isLost;
        itemDAO = new ItemDAO();

        setTitle(isLost ? "Report Lost Item" : "Report Found Item");
        setSize(700, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        getContentPane().setBackground(new Color(153,0,0));
        setLocationRelativeTo(null);
        setLayout(null);

        JLabel nameLabel = new JLabel("Item Name:");
        nameLabel.setBounds(50, 50, 100, 25);
        nameLabel.setForeground(Color.white);
        add(nameLabel);

        JTextField nameField = new JTextField();
        nameField.setBounds(150, 50, 150, 25);
        add(nameField);

        JLabel descLabel = new JLabel("Description:");
        descLabel.setBounds(50, 100, 100, 25);
        descLabel.setForeground(Color.white);
        add(descLabel);

        JTextField descField = new JTextField();
        descField.setBounds(150, 100, 150, 25);
        add(descField);

        JLabel dateLabel = new JLabel("Date:");
        dateLabel.setBounds(50, 150, 100, 25);
        dateLabel.setForeground(Color.white);
        add(dateLabel);

        JTextField dateField = new JTextField();
        dateField.setBounds(150, 150, 150, 25);
        add(dateField);

        JLabel contactLabel = new JLabel("Contact Info:");
        contactLabel.setBounds(50, 200, 100, 25);
        contactLabel.setForeground(Color.white);
        add(contactLabel);

        JTextField contactField = new JTextField();
        contactField.setBounds(150, 200, 150, 25);
        add(contactField);

        JButton submitButton = new JButton("Submit");
        submitButton.setBounds(150, 250, 100, 25);
        submitButton.setBorder(BorderFactory.createSoftBevelBorder(0));
        submitButton.setForeground(Color.white);
        submitButton.setBackground(new Color(153, 0, 0));
        add(submitButton);

        submitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String name = nameField.getText();
                String description = descField.getText();
                String date = dateField.getText();
                String contactInfo = contactField.getText();

                itemDAO.addItem(new Item(name, description, date, contactInfo, null), isLost);
                JOptionPane.showMessageDialog(ReportItemFrame.this, "Item reported successfully!");
                dispose();
            }
        });
    }
}

