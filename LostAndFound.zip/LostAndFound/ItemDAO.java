package LostAndFound;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ItemDAO {

    public void addItem(Item item, boolean isLost) {
        String table = isLost ? "lost_items" : "found_items";
        String sql = "INSERT INTO " + table + " (name, description, date, contact_info, picture_url) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = Database.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, item.getName());
            pstmt.setString(2, item.getDescription());
            pstmt.setString(3, item.getDate());
            pstmt.setString(4, item.getContactInfo());
            pstmt.setString(5, item.getPictureUrl());
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public List<Item> getItems(boolean isLost) {
        String table = isLost ? "lost_items" : "found_items";
        String sql = "SELECT * FROM " + table;
        List<Item> items = new ArrayList<>();
        try (Connection conn = Database.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                Item item = new Item(rs.getString("name"), rs.getString("description"), rs.getString("date"),
                        rs.getString("contact_info"), rs.getString("picture_url"));
                item.setId(rs.getInt("id"));
                item.setReturned(rs.getBoolean("is_returned"));
                items.add(item);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return items;
    }

    public void markItemAsReturned(int itemId, boolean isLost) {
        String table = isLost ? "lost_items" : "found_items";
        String sql = "UPDATE " + table + " SET is_returned = 1 WHERE id = ?";
        try (Connection conn = Database.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, itemId);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public List<Item> searchItems(String searchTerm, boolean isLost) {
        String table = isLost ? "lost_items" : "found_items";
        String sql = "SELECT * FROM " + table + " WHERE name LIKE ?";
        List<Item> items = new ArrayList<>();
        try (Connection conn = Database.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, "%" + searchTerm + "%");
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                Item item = new Item(rs.getString("name"), rs.getString("description"), rs.getString("date"),
                        rs.getString("contact_info"), rs.getString("picture_url"));
                item.setId(rs.getInt("id"));
                item.setReturned(rs.getBoolean("is_returned"));
                items.add(item);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return items;
    }

}
