package LostAndFound;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class ViewItemsFrame extends JFrame {
    private boolean isLost;
    private ItemDAO itemDAO;

    public ViewItemsFrame(boolean isLost) {
        this.isLost = isLost;
        itemDAO = new ItemDAO();

        setTitle(isLost ? "View Lost Items" : "View Found Items");
        setSize(700, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        getContentPane().setBackground(new Color(153, 0, 0));

        String[] columnNames = {"Name", "Description", "Date", "Contact Info", "Returned"};

        DefaultTableModel tableModel = new DefaultTableModel(columnNames, 0);

        List<Item> items = itemDAO.getItems(isLost);
        for (Item item : items) {
            Object[] row = {
                    item.getName(),
                    item.getDescription(),
                    item.getDate(),
                    item.getContactInfo(),
                    item.getId(),
                    item.isReturned(),
            };
            tableModel.addRow(row);
        }

        JTable table = new JTable(tableModel);
        table.setBackground(new Color(153, 0, 0));
        table.setForeground(Color.white);
        table.setFillsViewportHeight(true);

        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.getViewport().setBackground(new Color(153,0,0));

        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(new Color(153, 0, 0));
        panel.add(scrollPane, BorderLayout.CENTER);

        add(panel);

        setVisible(true);
    }

//    public static void main(String[] args) {
//        new ViewItemsFrame(true);
//    }
}
