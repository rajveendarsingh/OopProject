package LostAndFound;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MarkItemReturnedFrame extends JFrame {
    private boolean isLost;
    private ItemDAO itemDAO;

    public MarkItemReturnedFrame(boolean isLost) {
        this.isLost = isLost;
        itemDAO = new ItemDAO();

        setTitle(isLost ? "Mark Lost Item as Returned" : "Mark Found Item as Returned");
        setSize(700, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(null);

        getContentPane().setBackground(new Color(153, 0, 0));

        JLabel idLabel = new JLabel("Item Name:");
        idLabel.setBounds(50, 50, 100, 25);
        idLabel.setForeground(Color.WHITE);
        add(idLabel);

        JTextField idField = new JTextField();
        idField.setBounds(150, 50, 150, 25);
        add(idField);

        JButton markButton = new JButton("Mark as Returned");
        markButton.setBounds(150, 100, 150, 25);
        markButton.setBackground(new Color(153, 0, 0));
        markButton.setBorder(BorderFactory.createSoftBevelBorder(0));
        markButton.setForeground(Color.WHITE);
        add(markButton);

        markButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    int itemId = Integer.parseInt(idField.getText());
                    itemDAO.markItemAsReturned(itemId, isLost);
                    JOptionPane.showMessageDialog(MarkItemReturnedFrame.this, "Item marked as returned!");
                    dispose();
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(MarkItemReturnedFrame.this, "Please enter a valid name", "Error",
                            JOptionPane.ERROR_MESSAGE);
                }
            }
        });
    }

}
