package LostAndFound;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class AdminFrame extends JFrame {

    public AdminFrame() {
        setTitle("Admin Panel");
        setSize(800, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(null);

        JPanel leftPanel = new JPanel();
        leftPanel.setBackground(Color.BLACK);
        leftPanel.setBounds(0, 0, 350, 500);
        leftPanel.setLayout(null);

        ImageIcon imageIcon = new ImageIcon("C:\\Users\\hp\\IdeaProjects\\LostAndFoundSystem\\raj.jpg");
        Image image = imageIcon.getImage().getScaledInstance(leftPanel.getWidth(), leftPanel.getHeight(), Image.SCALE_SMOOTH); // Scale image to fit panel
        ImageIcon scaledImageIcon = new ImageIcon(image);

        JLabel imageLabel = new JLabel(scaledImageIcon);
        imageLabel.setBounds(0, 0, leftPanel.getWidth(), leftPanel.getHeight());
        leftPanel.add(imageLabel);

        JButton backButton = new JButton("Back");
        backButton.setBounds(15, 10, 80, 25);
        backButton.setBackground(new Color(153, 0, 0));
        backButton.setForeground(Color.white);
        backButton.setFocusable(false);
        leftPanel.add(backButton);

        add(leftPanel);

        JPanel rightPanel = new JPanel();
        rightPanel.setBackground(new Color(153, 0, 0));
        rightPanel.setBounds(350, 0, 450, 500);
        rightPanel.setLayout(null);

        // Buttons setup with Action Listeners
        JButton reportLostButton = new JButton("Report Lost Item");
        reportLostButton.setBounds(80, 50, 200, 25);
        reportLostButton.setBackground(new Color(153, 0, 0));
        reportLostButton.setForeground(Color.white);
        reportLostButton.setFocusable(false);
        rightPanel.add(reportLostButton);

        reportLostButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new ReportItemFrame(true).setVisible(true);
            }
        });

        JButton reportFoundButton = new JButton("Report Found Item");
        reportFoundButton.setBounds(80, 100, 200, 25);
        reportFoundButton.setBackground(new Color(153, 0, 0));
        reportFoundButton.setForeground(Color.white);
        reportFoundButton.setFocusable(false);
        rightPanel.add(reportFoundButton);

        reportFoundButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new ReportItemFrame(false).setVisible(true);
            }
        });

        JButton viewLostButton = new JButton("View Lost Items");
        viewLostButton.setBounds(80, 150, 200, 25);
        viewLostButton.setBackground(new Color(153, 0, 0));
        viewLostButton.setForeground(Color.white);
        viewLostButton.setFocusable(false);
        rightPanel.add(viewLostButton);

        viewLostButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new ViewItemsFrame(true).setVisible(true);
            }
        });

        JButton viewFoundButton = new JButton("View Found Items");
        viewFoundButton.setBounds(80, 200, 200, 25);
        viewFoundButton.setBackground(new Color(153, 0, 0));
        viewFoundButton.setForeground(Color.white);
        viewFoundButton.setFocusable(false);
        rightPanel.add(viewFoundButton);

        viewFoundButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new ViewItemsFrame(false).setVisible(true);
            }
        });

        JButton markLostReturnedButton = new JButton("Mark Lost Item as Returned");
        markLostReturnedButton.setBounds(80, 250, 200, 25);
        markLostReturnedButton.setBackground(new Color(153, 0, 0));
        markLostReturnedButton.setForeground(Color.white);
        markLostReturnedButton.setFocusable(false);
        rightPanel.add(markLostReturnedButton);

        markLostReturnedButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new MarkItemReturnedFrame(true).setVisible(true);
            }
        });

        JButton markFoundReturnedButton = new JButton("Mark Found Item as Returned");
        markFoundReturnedButton.setBounds(80, 300, 200, 25);
        markFoundReturnedButton.setBackground(new Color(153, 0, 0));
        markFoundReturnedButton.setForeground(Color.white);
        markFoundReturnedButton.setFocusable(false);
        rightPanel.add(markFoundReturnedButton);

        markFoundReturnedButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new MarkItemReturnedFrame(false).setVisible(true);
            }
        });


        add(rightPanel);

        setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new AdminFrame());
    }
}
