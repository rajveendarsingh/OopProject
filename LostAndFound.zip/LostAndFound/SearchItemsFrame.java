package LostAndFound;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class SearchItemsFrame extends JFrame {
    private boolean isLost;
    private ItemDAO itemDAO;

    public SearchItemsFrame(boolean isLost) {
        this.isLost = isLost;
        itemDAO = new ItemDAO();

        setTitle(isLost ? "Search Lost Items" : "Search Found Items");
        setSize(700, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        getContentPane().setBackground(new Color(153,0,0));
        setLocationRelativeTo(null);
        setLayout(null);

        JLabel searchLabel = new JLabel("Item Name:");
        searchLabel.setBounds(50, 50, 100, 25);
        searchLabel.setForeground(Color.white);
        add(searchLabel);

        JTextField searchField = new JTextField();
        searchField.setBounds(150, 50, 200, 25);
        add(searchField);

        JButton searchButton = new JButton("Search");
        searchButton.setBounds(370, 50, 100, 25);
        searchButton.setFocusable(false);
        searchButton.setForeground(Color.white);
        searchButton.setBackground(new Color(153,0,0));
        searchButton.setBorder(BorderFactory.createSoftBevelBorder(0));
        add(searchButton);

        JTextArea resultArea = new JTextArea();
        resultArea.setBounds(50, 100, 600, 250);
        resultArea.setEditable(false);
        add(resultArea);

        searchButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String searchTerm = searchField.getText();
                List<Item> items = itemDAO.searchItems(searchTerm, isLost);
                resultArea.setText("");
                for (Item item : items) {
                    resultArea.append(item.toString() + "\n------------------------\n");
                }
            }
        });
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new SearchItemsFrame(true).setVisible(true);
        });
    }
}
