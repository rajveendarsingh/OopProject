package LostAndFound;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MainFrame extends JFrame {
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JButton loginButton;
    private UserDAO userDAO;

    public MainFrame(boolean isAdmin) {
        userDAO = new UserDAO();

        setTitle("DHA SUFFA LOST AND FOUND SYSTEM");
        setSize(900, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(null);

        JPanel leftPanel = new JPanel();
        leftPanel.setBackground(Color.WHITE);
        leftPanel.setBounds(0, 0, 450, 600);
        leftPanel.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1, true));
        leftPanel.setLayout(null);

        String imagePath = "C:\\Users\\hp\\IdeaProjects\\LostAndFoundSystem\\raj2.jpg";

        ImageIcon imageIcon = new ImageIcon(imagePath);
        Image image = imageIcon.getImage().getScaledInstance(450, 600, Image.SCALE_SMOOTH);
        ImageIcon scaledImageIcon = new ImageIcon(image);

        JLabel imageLabel = new JLabel(scaledImageIcon);
        imageLabel.setBounds(0, 0, 450, 600);
        leftPanel.add(imageLabel);

        add(leftPanel);

        JPanel rightPanel = new JPanel();
        rightPanel.setBackground(new Color(153, 0, 0));
        rightPanel.setBounds(450, 0, 450, 600);
        rightPanel.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1, true));
        rightPanel.setLayout(null);

        JLabel titleLabel = new JLabel("DHA SUFFA LOST AND FOUND SYSTEM", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 16));
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setBounds(50, 30, 350, 25);
        rightPanel.add(titleLabel);

        JLabel usernameLabel = new JLabel("Username:");
        usernameLabel.setBounds(50, 150, 100, 25);
        usernameLabel.setForeground(Color.WHITE);
        rightPanel.add(usernameLabel);

        usernameField = new JTextField();
        usernameField.setBounds(150, 150, 200, 25);
        rightPanel.add(usernameField);

        JLabel passwordLabel = new JLabel("Password:");
        passwordLabel.setBounds(50, 200, 100, 25);
        passwordLabel.setForeground(Color.WHITE);
        rightPanel.add(passwordLabel);

        passwordField = new JPasswordField();
        passwordField.setBounds(150, 200, 200, 25);
        rightPanel.add(passwordField);

        loginButton = new JButton("Login");
        loginButton.setBounds(250, 250, 100, 35);
        loginButton.setBackground(new Color(153, 0, 0));
        loginButton.setForeground(Color.WHITE);
        loginButton.setBorder(BorderFactory.createSoftBevelBorder(0));
        loginButton.setFocusPainted(false);
        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String username = usernameField.getText();
                String password = new String(passwordField.getPassword());

                User user = userDAO.authenticate(username, password);
                if (user != null) {
                    if (user.isAdmin() && isAdmin) {
                        new AdminFrame().setVisible(true);
                    } else if (!user.isAdmin() && !isAdmin) {
                        new UserFrame().setVisible(true);
                    } else {
                        JOptionPane.showMessageDialog(MainFrame.this, "Incorrect login type selected", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                    dispose();
                } else {
                    JOptionPane.showMessageDialog(MainFrame.this, "Invalid credentials", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });
        rightPanel.add(loginButton);

        JButton backButton = new JButton("Back");
        backButton.setBounds(250, 300, 100, 35);
        backButton.setBackground(new Color(153, 0, 0));
        backButton.setForeground(Color.WHITE);
        backButton.setBorder(BorderFactory.createSoftBevelBorder(0));
        backButton.setFocusPainted(false);
        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new SelectionFrame().setVisible(true);
                dispose();
            }
        });
        rightPanel.add(backButton);

        add(rightPanel);

        setVisible(true);
    }

    //    public static void main(String[] args) {
    //        new MainFrame(false);
    //    }
}
