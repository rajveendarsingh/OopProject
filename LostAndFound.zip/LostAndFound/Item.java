package LostAndFound;
public class Item {
    private int id;
    private String name;
    private String description;
    private String date;
    private String contactInfo;
    private boolean isReturned;
    private String pictureUrl;

    public Item(String name, String description, String date, String contactInfo, String pictureUrl) {
        this.name = name;
        this.description = description;
        this.date = date;
        this.contactInfo = contactInfo;
        this.pictureUrl = pictureUrl;
        this.isReturned = false;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    public String getDate() {
        return date;
    }

    public String getContactInfo() {
        return contactInfo;
    }

    public boolean isReturned() {
        return isReturned;
    }

    public void setReturned(boolean returned) {
        isReturned = returned;
    }

    public String getPictureUrl() {
        return pictureUrl;
    }

    @Override
    public String toString() {
        return "Item{" +
                "name='" + name + '\'' +
                ", description='" + description + '\'' +
                ", date='" + date + '\'' +
                ", contactInfo='" + contactInfo + '\'' +
                ", isReturned=" + isReturned +
                ", pictureUrl='" + pictureUrl + '\'' +
                '}';
    }
}

