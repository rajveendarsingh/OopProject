package LostAndFound;

import javax.swing.*;
import java.awt.*;

public class UserFrame extends JFrame {
    public UserFrame() {
        setTitle("User Panel");
        setSize(700, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        getContentPane().setBackground(new Color(153,0,0));
        setLayout(null);

        JButton viewLostButton = new JButton("View Lost Items");
        viewLostButton.setBounds(250, 50, 200, 35);
        viewLostButton.setBackground(new Color(153,0,0));
        viewLostButton.setForeground(Color.white);
        viewLostButton.setFocusable(false);
        viewLostButton.setBorder(BorderFactory.createSoftBevelBorder(0));
        add(viewLostButton);

        JButton viewFoundButton = new JButton("View Found Items");
        viewFoundButton.setBounds(250, 100, 200, 35);
        viewFoundButton.setBackground(new Color(153,0,0));
        viewFoundButton.setForeground(Color.white);
        viewFoundButton.setFocusable(false);
        viewFoundButton.setBorder(BorderFactory.createSoftBevelBorder(0));
        add(viewFoundButton);

        JButton searchLostButton = new JButton("Search Lost Items");
        searchLostButton.setBounds(250, 150, 200, 35);
        searchLostButton.setBackground(new Color(153,0,0));
        searchLostButton.setForeground(Color.white);
        searchLostButton.setFocusable(false);
        searchLostButton.setBorder(BorderFactory.createSoftBevelBorder(0));
        add(searchLostButton);

        JButton searchFoundButton = new JButton("Search Found Items");
        searchFoundButton.setBounds(250, 200, 200, 35);
        searchFoundButton.setBackground(new Color(153,0,0));
        searchFoundButton.setForeground(Color.white);
        searchFoundButton.setFocusable(false);
        searchFoundButton.setBorder(BorderFactory.createSoftBevelBorder(0));
        add(searchFoundButton);

        viewLostButton.addActionListener(e -> {
            new ViewItemsFrame(true).setVisible(true);
        });

        viewFoundButton.addActionListener(e -> {
            new ViewItemsFrame(false).setVisible(true);
        });

        searchLostButton.addActionListener(e -> {
            new SearchItemsFrame(true).setVisible(true);
        });

        searchFoundButton.addActionListener(e -> {
            new SearchItemsFrame(false).setVisible(true);
        });
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new UserFrame().setVisible(true);
        });
    }
}
